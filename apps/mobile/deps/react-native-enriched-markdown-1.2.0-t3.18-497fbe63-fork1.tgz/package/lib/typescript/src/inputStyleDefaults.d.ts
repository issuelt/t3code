export declare const DEFAULT_LINK_COLOR = "#2563EB";
export declare const DEFAULT_LINK_BG_COLOR = "transparent";
export declare const DEFAULT_SPOILER_COLOR = "#374151";
export declare const DEFAULT_SPOILER_BG_COLOR = "#E5E7EB";
//# sourceMappingURL=inputStyleDefaults.d.ts.map